import logo from "./logo.svg";
import "./App.css";
import Login from "./components/Login";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import React from "react";
import Home from "./components/pages/Home";
import Navbar from "./components/Navbar";
import SignUp from "./components/pages/SignUp";
import Registration from "./components/Registration";

function App() {
  return (
    <>
      <Router>
        <Navbar />
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/login" component={Login} />
          <Route path="/signup" component={Registration} />
        </Switch>
      </Router>
    </>
  );
}

export default App;
